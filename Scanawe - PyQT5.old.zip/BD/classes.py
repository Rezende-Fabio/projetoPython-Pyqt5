from BD.schema import Conexao
from sqlite3 import Error, connect

class Login:

	def valida_login(login, senha):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("""SELECT l.idLogin, l.login, l.senha, p.permissao, pe.nomePessoa
			FROM LOGIN l INNER JOIN PESSOA pe 
			ON l.idPessoa = pe.idPessoa
			INNER JOIN PERFIL p ON p.permissao = pe.permissao;""")   
		linhas = conecta.fetchall()
		for x in linhas:
			if x[1] == login and x[2] == senha:
				valid =  True
				id = x[0]
				permissao = x[3]
				nome_usario = x[4]
				break
			else:
				valid = False
				id = None
				permissao = ""
				nome_usario = ""
		
		if permissao == 2:
			conecta.execute(f"""SELECT e.siglaEmpresa
				FROM LOGIN l INNER JOIN PESSOA s ON s.idPessoa = l.idPessoa
				INNER JOIN EMPRESA e ON s.siglaEmpresa = e.siglaEmpresa
				WHERE l.idLogin = {id};""")
			linhas = conecta.fetchall()
			for x in linhas:
				sigla_empresa = x[0]
		else:
			sigla_empresa = ""
		
		return (valid, id, sigla_empresa, nome_usario)
	
	def valida_permissao(id):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT p.permissao
			FROM LOGIN l INNER JOIN PESSOA pe ON l.idPessoa = pe.idPessoa 
			INNER JOIN PERFIL p ON p.permissao = pe.permissao
			WHERE idLogin = {id};""")
		linhas = conecta.fetchall()

		return linhas[0]

	def insert_login(login, senha, id_pessoa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("INSERT INTO LOGIN (login, senha, idPessoa) VALUES (?,?,?)", (login, senha, id_pessoa))
		conecta.commit()


class Token:

	def insert_token(token):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("INSERT INTO TOKEN (token) VALUES (?)", (token,))
		conecta.commit()   

	def valida_token(token):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("SELECT token FROM TOKEN;")  
		linhas = conecta.fetchall()
		for x in linhas:
			if x[0] == token:
				valid = True
				break
			else: 
				valid = False

		return valid	

	def id_token_colaborador():	
		conecta = Conexao()
		conecta.connect()
		conecta.execute("SELECT idToken FROM TOKEN;")
		linhas_token = conecta.fetchall()
		for x in linhas_token:
			id_token = x[0]
		
		return id_token

	def incrementa_token():
		conecta = Conexao()
		conecta.connect()
		conecta.execute("SELECT token FROM TOKEN;")
		linhas_token = conecta.fetchall()
		for x in linhas_token:
			token = x[0]
		
		token = int(token) + 1	
		Token.insert_token(token)

	def gera_token_colaborador(sigla_empresa):
		num_colab = Pessoa.numero_colab_token(sigla_empresa)
		id_colab = Pessoa.id_num_colab(sigla_empresa)
		for x in range(0, int(num_colab[0])):
			Token.incrementa_token()
			id_token = Token.id_token_colaborador()
			Pessoa.update_token(id_token, id_colab[x][0])
		
	def token_email():
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("SELECT token FROM TOKEN;")  
		linhas = conecta.fetchall()
		for x in linhas:
			token = x[0]

		return token


class Endereco:

	def insert_endereco(estado, cidade, bairro, rua, numero, complemento, cep):
		conecta = Conexao()
		conecta.connect()  
		conecta.execute("""INSERT INTO ENDERECO (estado, cidade, bairro, rua, numero, complemento, cep)
			VALUES (?,?,?,?,?,?,?)""", (estado, cidade, bairro, rua, numero, complemento, cep))
		conecta.commit()
		"""except:
			return False
		else:
			return True"""
	
	def id_endereco_empresa():
		conecta = Conexao()
		conecta.connect()  
		conecta.execute("SELECT idEndereco FROM ENDERECO")
		linhas = conecta.fetchall()
		for x in linhas:
			id = x[0]

		return id
	
	def excluir_endereco(id):
		conecta = Conexao()
		conecta.connect()  
		conecta.execute(f"DELETE FROM ENDERECO WHERE idEndereco = {id[0]};")
		conecta.commit()	


class Empresa:

	def insert_empresa(sigla, nome, cnpj, id_endereco):
		try:
			conecta = Conexao()
			conecta.connect()
			conecta.execute("""INSERT INTO EMPRESA (siglaEmpresa, nomeEmpresa, cnpj, idEndereco) 
				VALUES (?,?,?,?)""", (sigla, nome, cnpj, id_endereco))
			conecta.commit()
		except:
			return False
		else:
			return True
	
	def view_empresa():
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("""SELECT e.siglaEmpresa, e.nomeEmpresa, e.cnpj, ed.estado, ed.cidade, ed.bairro, ed.rua, ed.numero, ed.cep, ed.complemento 
			FROM EMPRESA e inner join ENDERECO ed on e.idEndereco = ed.idEndereco;""")   
		linhas = conecta.fetchall()

		return linhas
	
	def view_empresa_pesquisa(nome_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT e.siglaEmpresa, e.nomeEmpresa, e.cnpj, ed.estado, ed.cidade, ed.bairro, ed.rua, ed.numero, ed.cep, ed.complemento 
			FROM EMPRESA e inner join ENDERECO ed on e.idEndereco = ed.idEndereco WHERE e.nomeEmpresa LIKE '%{nome_empresa}%';""")   
		linhas = conecta.fetchall()

		return linhas
	
	def view_sigla_Empresa():
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("SELECT siglaEmpresa FROM EMPRESA;")
		linhas = conecta.fetchall()

		return linhas
	
	def campos_atualizar(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT e.siglaEmpresa, e.nomeEmpresa, e.cnpj, ed.estado, ed.cidade, ed.bairro, 
			ed.rua, ed.numero, ed.cep, ed.complemento 
			FROM EMPRESA e inner join ENDERECO ed on e.idEndereco = ed.idEndereco 
			WHERE e.siglaEmpresa = '{sigla_empresa}';""")
		linhas = conecta.fetchall()

		return linhas[0]
	
	def quantidade_de_empresas():
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("SELECT count(siglaEmpresa) FROM EMPRESA;")
		linhas = conecta.fetchall()

		return linhas[0]

	def id_endereco(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"SELECT idEndereco FROM EMPRESA WHERE siglaEmpresa = '{sigla_empresa}';")
		linhas = conecta.fetchall()

		return linhas[0]
	
	def excluir_empresas(sigla_empresa):
		id_enderco = Empresa.id_endereco(sigla_empresa)
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"DELETE FROM EMPRESA WHERE siglaEmpresa = '{sigla_empresa}';")
		conecta.commit()
		Endereco.excluir_endereco(id_enderco)


class Setor:

	def view_setor(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT se.siglaSetor, se.nomeSetor, se.localizacao, se.ramal, se.setorPai, se.descricaoSetor 
			FROM SETOR se WHERE se.siglaEmpresa = '{sigla_empresa}';""")
		linhas = conecta.fetchall()

		return linhas
	
	def view_sigla_setor(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"SELECT se.siglaSetor FROM SETOR se WHERE se.siglaEmpresa = '{sigla_empresa}';")
		linhas = conecta.fetchall()

		return linhas

	def view_setor_pesquisa(nome_pesquisa, sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT se.siglaSetor, se.nomeSetor, se.localizacao, se.ramal, se.setorPai, se.descricaoSetor
			FROM SETOR se WHERE se.nomeSetor LIKE '%{nome_pesquisa}%' and se.siglaEmpresa = '{sigla_empresa}';""")
		linhas = conecta.fetchall()

		return linhas
	
	def insert_setor(sigla_setor, nome_setor, loc_setor, ramal_setor, setor_pai, desc_setor, sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("""INSERT INTO SETOR 
			(siglaSetor, nomeSetor, localizacao, ramal, setorPai, descricaoSetor, siglaEmpresa)
			VALUES (?,?,?,?,?,?,?);""", 
			(sigla_setor, nome_setor, loc_setor, ramal_setor, setor_pai, desc_setor, sigla_empresa))
		conecta.commit()
	
	def campos_atualizar(sigla_setor, sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT nomeSetor, siglaSetor, localizacao, setorPai, ramal, descricaoSetor 
			FROM SETOR WHERE siglaSetor = '{sigla_setor}' and siglaEmpresa = '{sigla_empresa}';""")
		linhas = conecta.fetchall()

		return linhas[0]

	def excluir_setor(sigla_setor):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"DELETE FROM SETOR WHERE siglaSetor = '{sigla_setor}';")
		conecta.commit()
	
	def quantidade_setor_cadastrados(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"SELECT count(siglaSetor) FROM SETOR WHERE siglaEmpresa = '{sigla_empresa}';")
		linhas = conecta.fetchall()

		return linhas[0]


class Pessoa():
	
	def insert_pessoa(nome, email, tel, cargo, cpf, validPermisao, siglaStor, siglaEmpresa):
		try:
			conecta = Conexao()
			conecta.connect()
			Token.incrementa_token()
			id_token = Token.id_token_colaborador()
			conecta.execute("""INSERT INTO PESSOA (nomePessoa, email, telefone, cargo, cpf, idToken, permissao, siglaSetor, siglaEmpresa) 
				VALUES (?,?,?,?,?,?,?,?,?);""",(nome, email, tel, cargo, cpf, id_token, validPermisao, siglaStor, siglaEmpresa))
			conecta.commit()
		except:
			return False
		else: 
			return True
	
	def insert_gestor(nome, email, tel, cargo, cpf, validPermisao, siglaStor, siglaEmpresa):
		try:
			conecta = Conexao()
			conecta.connect()
			id_token = ""
			conecta.execute("""INSERT INTO PESSOA (nomePessoa, email, telefone, cargo, cpf, idToken, permissao, siglaSetor, siglaEmpresa) 
				VALUES (?,?,?,?,?,?,?,?,?);""",(nome, email, tel, cargo, cpf, id_token, validPermisao, siglaStor, siglaEmpresa))
			conecta.commit()
		except:
			return False
		else: 
			return True

	def view_pessoa(sigla_empresa):
		conecta = Conexao()
		conecta.connect()
		conecta.execute(f"""SELECT pe.idPessoa, pe.nomePessoa,  	pe.email, pe.telefone, pe.cargo
			FROM PESSOA pe
			WHERE pe.siglaEmpresa = '{sigla_empresa}';""")    
		linhas = conecta.fetchall()

		return linhas
	
	def id_login():
		conecta = Conexao()
		conecta.connect()
		conecta.execute("SELECT idPessoa FROM PESSOA;")
		linhas = conecta.fetchall()
		for x in linhas:
			id_pessoa = x[0]
		
		return id_pessoa
	
	def view_pessoa_pesquisa(nome_pesquisa, sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"SELECT idPessoa, nomePessoa, email, telefone, cargo FROM PESSOA WHERE nomePessoa LIKE '%{nome_pesquisa}%' and siglaEmpresa = '{sigla_empresa}';")   
		linhas = conecta.fetchall()

		return linhas
	
	def campos_atulizar(id):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"SELECT nomePessoa, cpf, email, telefone, cargo, siglaSetor FROM PESSOA WHERE idPessoa = {id};")   
		linhas = conecta.fetchall()

		return linhas[0]
	
	def numero_colab_token(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT count(p.idPessoa) 
			FROM PESSOA p WHERE p.permissao = 3 AND p.siglaEmpresa = '{sigla_empresa}';""")
		linhas = conecta.fetchall()

		return linhas[0]
	
	def id_num_colab(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT p.idPessoa 
			FROM PESSOA p WHERE p.permissao = 3 AND p.siglaEmpresa = '{sigla_empresa}';""")
		linhas = conecta.fetchall()

		return linhas

	def update_token(id_token, id_pessoa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""UPDATE PESSOA SET idToken = {id_token} WHERE idPessoa = {id_pessoa};""")
		conecta.commit()
	
	def veiw_pessoa_gerar_token(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"""SELECT pe.nomePessoa, se.nomeSetor,
			tk.token
			FROM PESSOA pe INNER JOIN SETOR se 
			ON pe.siglaSetor = se.siglaSetor
			INNER JOIN TOKEN tk 
			ON pe.idToken = tk.idToken
			WHERE pe.siglaEmpresa = '{sigla_empresa}'
			ORDER BY pe.nomePessoa;""")
		linhas = conecta.fetchall()

		return linhas
	
	def excluir_pessoa(id):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"DELETE FROM PESSOA WHERE idPessoa = {id};")
		conecta.commit()
	
	def quantidade_pessoas_cadastradas(sigla_empresa):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute(f"SELECT count(idPessoa) FROM PESSOA WHERE siglaEmpresa = '{sigla_empresa}';")
		linhas = conecta.fetchall()

		return linhas[0]


class Questionario:
	def __init__(self, siglaQuestionario, tituloQuestionario, dataInicio, dataFinal):
		self.siglaQuestionario = siglaQuestionario	
		self.tituloQuestionario = tituloQuestionario
		self.dataInicio = dataInicio
		self.dataFinal = dataFinal


class Relatorio:
	def __init__(self, siglaRelatorio, tituloRelatorio, data):
		self.siglaRelatorio = siglaRelatorio	
		self.tituloRelatorio = tituloRelatorio
		self.data = data


class Questao:
	def __init__(self, tipo, descricaoQuestao):	
		self.tipo = tipo
		self.descricaoQuestao = descricaoQuestao


class Resposta:
	def insert_resposta(resposta, id_questao):
		conecta = Conexao()
		conecta.connect()   
		conecta.execute("INSERT INTO RESPOSTA (descricaoResposta, idQuestao) VALUES (?,?);", (resposta, id_questao))
		conecta.commit()


if __name__ == "__main__":
	Token.insert_token(4002)