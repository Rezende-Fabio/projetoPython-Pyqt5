from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
from PyQt5.Qt import Qt
from PyQt5.QtCore import pyqtSlot, QPropertyAnimation
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon, QPixmap, QKeyEvent
from PyQt5.QtPrintSupport import *
import os, sys

from Templates.Mensagem import Ui_Dialog

class Mensagem(QDialog):
    def __init__(self, *args, **argvs):
        super(Mensagem,self).__init__(*args, **argvs)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.fechar)

    def fechar(self):
        Mensagem.hide(self)